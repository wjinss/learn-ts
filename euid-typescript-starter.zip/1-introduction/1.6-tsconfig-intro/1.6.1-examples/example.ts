const message: string = '안녕! 타입스크립트 컴파일러. 이 파일을 자바스크립트 파일로 컴파일 해줘! 🦁'

console.log(message)
