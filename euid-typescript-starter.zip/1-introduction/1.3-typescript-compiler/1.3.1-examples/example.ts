const message: string = '안녕! TypeScript 🦁'

console.log(message)
