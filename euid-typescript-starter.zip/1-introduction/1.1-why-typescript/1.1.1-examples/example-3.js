// 일반 JavaScript 함수
function add(a, b) {
  return a + b
}
