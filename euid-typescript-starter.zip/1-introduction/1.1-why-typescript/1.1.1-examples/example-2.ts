// 타입이 지정된 TypeScript 변수
let age: number = 20

age = 9 // 지정된 타입과 같은 값이라 할당에 문제 없음

// age = '스물' // Error: Type 'string' is not assignable to type 'number'.
