// 일반 JavaScript 변수
let age = 20