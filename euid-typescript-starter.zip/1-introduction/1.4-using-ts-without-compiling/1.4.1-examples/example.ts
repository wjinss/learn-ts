const message: string = '컴파일 없이 TypeScript 실행이 가능합니다. 🦁'

console.log(message)
