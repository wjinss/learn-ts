const message: string = '안녕! Bun. 타입스크립트를 바로 실행해줘! 🦁'

console.log(message)
