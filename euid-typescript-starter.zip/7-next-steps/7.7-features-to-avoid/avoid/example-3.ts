// 네임스페이스(namespace) 사용을 피하세요.
export namespace Utils {
  export function greet(): string {
    return '안녕!'
  }
}
