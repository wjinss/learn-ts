// 일반 enum은 피하세요.
enum Status {
  Active,
  Inactive,
  Pending,
  Deleted,
}
