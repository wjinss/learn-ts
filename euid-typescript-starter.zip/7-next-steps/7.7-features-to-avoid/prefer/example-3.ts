// ES 모듈 사용을 권장합니다
export const utils = {
  greet() {
    return '안녕!'
  },
}