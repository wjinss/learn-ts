// 삼각형의 넓이를 계산하는 함수
export function calculateTriangleArea(base: number, height: number): number {
  return (base * height) / 2
}