// 객체 리터럴 (Object literal)
const user = { name: '진우' }

// Error: Property 'toUppercase' does not exist on type 'string'.
// const uppercaseName = user.name.toUppercase()
