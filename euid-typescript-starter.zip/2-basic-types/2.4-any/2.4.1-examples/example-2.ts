//  어떤 타입이든 받을 수 있는 함수 선언
function logValue(value: any) {
  console.log(value)
}

logValue(42)
logValue('안녕! 타입스크립트!')
