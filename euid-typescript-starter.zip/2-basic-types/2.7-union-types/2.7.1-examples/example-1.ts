function printId(id: number | string) {
  console.log(`ID: ${id}`)
}

printId(123)
//^?

printId('abc')
//^?

