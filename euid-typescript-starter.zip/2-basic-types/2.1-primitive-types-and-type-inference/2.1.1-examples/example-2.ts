// 추론된 타입
let age = 42
let message = '안녕, TypeScript 🦁'
let isAdmin = true
let nullThing = null
let undefinedThing = undefined
