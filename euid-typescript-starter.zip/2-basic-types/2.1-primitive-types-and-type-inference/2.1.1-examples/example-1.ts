// 명시적 타입
let age: number = 42
let message: string = '안녕, TypeScript 🦁'
let isAdmin: boolean = true
let nullThing: null = null
let undefinedThing: undefined = undefined
