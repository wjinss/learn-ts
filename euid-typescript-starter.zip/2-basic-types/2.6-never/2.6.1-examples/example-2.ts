function infiniteLoop(): never {
  while (true) {
    console.log('무한 루프는 발생하면 안되는 상황입니다.')
  }
}

infiniteLoop()
//^?
