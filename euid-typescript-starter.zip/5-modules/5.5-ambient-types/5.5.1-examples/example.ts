// `myLibrary` 객체를 사용해보세요.
// 타입스크립트의 타입 지원과 자동완성 기능을 활용할 수 있습니다.

console.log(myLibrary.version)
console.log(myLibrary.add(1, 2))
