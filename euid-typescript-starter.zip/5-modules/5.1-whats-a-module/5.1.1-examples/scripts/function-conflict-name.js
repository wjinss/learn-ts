var conflictName = function() {
  return '함수 표현식'
}