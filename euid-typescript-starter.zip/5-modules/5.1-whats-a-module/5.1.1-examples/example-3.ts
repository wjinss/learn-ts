// 이 파일은 export 문이 있기 때문에 ES 모듈(ES module)입니다.

export {}
