export type Product = {
  name: string
  price: number
}

export function hello() {
  return '안녕!'
}
