// ES 모듈 내보내기 구문
export function myFunction() {
  // ...
}

// CommonJS 모듈 내보내기 구문
module.exports = {
  myFunction,
};
