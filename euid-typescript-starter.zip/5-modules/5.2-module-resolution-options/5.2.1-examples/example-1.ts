// ES 모듈 불러오기 구문
import { myFunction } from './example-2'

// CommonJS 모듈 불러오기 구문
const cjsExample = require('./example-2')
