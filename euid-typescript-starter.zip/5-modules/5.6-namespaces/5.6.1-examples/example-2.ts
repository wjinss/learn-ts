// 네임스페이스 없이도 결과는 동일합니다.

export const myVar = '공개 변수'
const myPrivateVar = '비공개 변수!'