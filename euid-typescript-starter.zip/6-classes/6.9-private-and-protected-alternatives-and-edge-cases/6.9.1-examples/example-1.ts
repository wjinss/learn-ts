// private 필드를 가진 예시 클래스
export class User {
  private password = '123'
}