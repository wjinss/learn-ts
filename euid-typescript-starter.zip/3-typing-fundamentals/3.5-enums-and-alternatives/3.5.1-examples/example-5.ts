// enum 멤버의 값으로 계산된 값을 사용할 수도 있습니다.
// 이 예시에서 Red는 "red".length로 3, Green은 "green".length로 5의 값을 갖게 됩니다.
enum ColorComputed {
  Red = 'red'.length,
  Green = 'green'.length,
}

