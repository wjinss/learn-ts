// 명시적인 숫자 값 할당
enum Color {
  Red = 1,
  Green = 2,
  Blue = 3,
}
