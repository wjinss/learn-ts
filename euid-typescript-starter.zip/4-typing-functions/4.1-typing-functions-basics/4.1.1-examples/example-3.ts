// 함수가 아무것도 반환하지 않음을 void 타입으로 명시할 수도 있습니다.
function greet(name: string): void {
  console.log(`Hello, ${name}!`)
}
