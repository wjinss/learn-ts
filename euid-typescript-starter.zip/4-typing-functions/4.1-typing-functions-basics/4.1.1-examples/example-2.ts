// 반환 타입은 선택 사항이며, TypeScript가 추론할 수 있습니다.
function add(a: number, b: number) {
  return a + b
}
