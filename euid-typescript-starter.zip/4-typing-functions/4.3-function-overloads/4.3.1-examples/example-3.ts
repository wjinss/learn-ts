// 오버로딩 대신, 명확한 이름의 별도 함수를 고려하세요.
function addNumbers(a: number, b: number) {
  return a + b
}

function concatenate(a: string, b: string) {
  return a + b
}