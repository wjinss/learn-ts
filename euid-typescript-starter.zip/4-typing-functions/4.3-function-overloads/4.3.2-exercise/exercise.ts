// Exercise 1: Create function overloads for a function named `getLength`
// that can take either a string or an array and return their length.

// Test your implementation:
// getLength("TypeScript"); // 10
// getLength([1, 2, 3, 4, 5]); // 5
